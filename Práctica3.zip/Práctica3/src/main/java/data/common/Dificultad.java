package data.common;

/**
 * Listed which will establish the difficulty of the track
 * @author Antonio Diaz Perez
 * @version 07/10/2022
 */


/* Define the variable type State to define the dificulty of the pista */
public enum Dificultad{
	infantil, familiar, adultos
};